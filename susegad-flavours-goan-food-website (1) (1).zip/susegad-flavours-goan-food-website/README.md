# Susegad flavours goan food website 

A Pen created on CodePen.

Original URL: [https://codepen.io/Rivaldo-Leander-Fernandes/pen/wBMzwOe](https://codepen.io/Rivaldo-Leander-Fernandes/pen/wBMzwOe).

